def display_student_details():
    # Code to print student details goes here.
    print("Student details displayed")

