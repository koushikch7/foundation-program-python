from result. manage_score import get_grade


def update_student_grade():
    average = 72 # Assumed average score of the student
    grade = get_grade(average)
    
    # Code to update details goes here
    print("Grade updated for student")    
