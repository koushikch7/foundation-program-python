from student.show_student_details import display_student_details

def display_result():
    display_student_details()
    #Insert relevant code here

'''
## Other two ways to import are: ##

from student import show_student_details

def display_result():
    show_student_details.display_student_details()
    #code to display score goes here
    
  
import student.show_student_details

def display_result():
    student.show_student_details.display_student_details()
    #code to display score goes here


'''


