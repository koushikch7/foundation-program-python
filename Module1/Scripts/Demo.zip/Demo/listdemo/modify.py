def add_element():
    # More code goes here
    print("Element added in the list")
