''' We want to access add_element() function from both the modules here'''

#Insert relevant code here
