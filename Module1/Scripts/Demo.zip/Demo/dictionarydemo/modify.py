def add_element():
    # M code goes here
    print("Element added in the dictionary")